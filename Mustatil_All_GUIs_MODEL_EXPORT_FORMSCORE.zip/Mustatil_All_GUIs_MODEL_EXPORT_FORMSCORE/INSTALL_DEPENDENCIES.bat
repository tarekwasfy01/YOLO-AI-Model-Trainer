@echo off
setlocal
cd /d "%~dp0"
echo Installing required Python packages for Mustatil All GUIs...
echo.
py -3.11 --version >nul 2>&1
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    py -3.10 --version >nul 2>&1
    if %errorlevel%==0 (
        set PY=py -3.10
    ) else (
        set PY=python
    )
)
%PY% -m pip install --upgrade pip
%PY% -m pip install pillow numpy pyyaml tqdm pandas matplotlib opencv-python
%PY% -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
%PY% -m pip install ultralytics onnx onnxruntime onnxruntime-directml
%PY% -m pip install rasterio shapely
if errorlevel 1 (
    echo.
    echo Installation finished with errors. Python 3.10 or 3.11 is strongly recommended.
    pause
    exit /b 1
)
echo.
echo Installation finished.
pause
