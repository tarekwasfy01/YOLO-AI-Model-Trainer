@echo off
setlocal
cd /d "%~dp0"
echo Starting Mustatil All GUIs...
py -3.11 mustatil_all_guis.py
if errorlevel 1 (
    py -3.10 mustatil_all_guis.py
)
if errorlevel 1 (
    python mustatil_all_guis.py
)
if errorlevel 1 (
    echo.
    echo Start failed. Run INSTALL_DEPENDENCIES.bat first and prefer Python 3.10/3.11.
    pause
)
