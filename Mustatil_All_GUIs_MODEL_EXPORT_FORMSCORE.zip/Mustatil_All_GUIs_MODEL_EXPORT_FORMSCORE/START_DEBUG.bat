@echo off
setlocal
cd /d "%~dp0"
echo Debug start. This window stays open.
echo.
python --version
python mustatil_all_guis.py
echo.
pause
