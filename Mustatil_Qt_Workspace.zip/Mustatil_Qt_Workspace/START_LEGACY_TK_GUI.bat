@echo off
setlocal
cd /d "%~dp0"
python mustatil_legacy_backend.py
if errorlevel 1 pause
