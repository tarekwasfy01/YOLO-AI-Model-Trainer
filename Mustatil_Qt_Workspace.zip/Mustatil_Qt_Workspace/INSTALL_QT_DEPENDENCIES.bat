@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo Install Mustatil Qt dependencies
 echo ============================================================
python -m pip install --upgrade pip setuptools wheel
python -m pip install PySide6 Pillow numpy pyyaml opencv-python shapely fiona rasterio ultralytics onnxruntime
if errorlevel 1 (
  echo.
  echo Dependency installation failed.
  pause
  exit /b 1
)
echo.
echo Done.
pause
