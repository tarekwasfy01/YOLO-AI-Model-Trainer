@echo off
setlocal
cd /d "%~dp0"
python mustatil_qt_workspace.py
if errorlevel 1 pause
