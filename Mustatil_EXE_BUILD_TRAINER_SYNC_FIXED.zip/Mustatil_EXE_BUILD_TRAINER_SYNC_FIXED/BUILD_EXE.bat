@echo off
setlocal
cd /d "%~dp0"
title Build Mustatil EXE

echo ============================================================
echo Building Mustatil_All_GUIs.exe
 echo Console window disabled for normal use
echo ============================================================

where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    set PY=python
)

%PY% --version
if errorlevel 1 (
    echo Python not found.
    pause
    exit /b 1
)

echo Checking PyInstaller...
%PY% -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
    echo PyInstaller missing. Installing now...
    %PY% -m pip install pyinstaller
    if errorlevel 1 (
        echo PyInstaller install failed.
        pause
        exit /b 1
    )
)

%PY% -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --name Mustatil_All_GUIs ^
  --collect-all ultralytics ^
  --collect-all torch ^
  --collect-all torchvision ^
  --collect-all onnxruntime ^
  --hidden-import PIL._tkinter_finder ^
  --hidden-import cv2 ^
  --hidden-import yaml ^
  --hidden-import numpy ^
  --hidden-import pandas ^
  --hidden-import matplotlib ^
  --hidden-import rasterio ^
  --hidden-import shapely ^
  mustatil_all_guis.py

if errorlevel 1 (
    echo.
    echo EXE build failed. Run BUILD_EXE_DEBUG.bat for details.
    pause
    exit /b 1
)

echo.
echo Build finished: dist\Mustatil_All_GUIs.exe
pause
