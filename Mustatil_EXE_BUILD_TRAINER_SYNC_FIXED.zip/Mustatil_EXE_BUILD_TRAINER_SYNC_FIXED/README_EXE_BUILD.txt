Mustatil All GUIs - EXE build package
=====================================

Files:
- mustatil_all_guis.py
- START_MUSTATIL_ALL_GUIS.bat
- START_DEBUG.bat
- INSTALL_DEPENDENCIES.bat
- BUILD_EXE.bat
- BUILD_EXE_DEBUG.bat

Recommended Python:
- Python 3.10 or 3.11, 64-bit.
- Python 3.14 is not recommended for Torch/Ultralytics/SAM.

Build steps:
1. Run INSTALL_DEPENDENCIES.bat
2. Run START_DEBUG.bat once to verify the GUI starts.
3. Run BUILD_EXE_DEBUG.bat first.
4. If the debug EXE works, run BUILD_EXE.bat for the windowed EXE.

Trainer sync fix:
- The Crop Annotator now writes YOLO labels immediately into project/labels.
- crop_manifest.json is updated with review status and annotation boxes.
- Before preparing the YOLO dataset, the trainer synchronizes labels from:
  1) project/images/*.txt sidecars,
  2) project/crop_manifest.json reviewed annotations,
  3) project/labels/*.txt.
- Neutral/unreviewed crops are skipped.
- POSITIVE is class 0. FALSE positive is class 1.

Output:
- The built EXE is created under dist\.
