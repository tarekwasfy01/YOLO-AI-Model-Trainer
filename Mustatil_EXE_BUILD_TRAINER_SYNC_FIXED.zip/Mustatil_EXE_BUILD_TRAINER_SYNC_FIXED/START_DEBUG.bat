@echo off
setlocal
cd /d "%~dp0"
title Mustatil All GUIs DEBUG

echo ============================================================
echo Mustatil All GUIs - DEBUG START
echo ============================================================
where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    set PY=python
)

%PY% --version
%PY% mustatil_all_guis.py

echo.
echo Debug session ended.
pause
