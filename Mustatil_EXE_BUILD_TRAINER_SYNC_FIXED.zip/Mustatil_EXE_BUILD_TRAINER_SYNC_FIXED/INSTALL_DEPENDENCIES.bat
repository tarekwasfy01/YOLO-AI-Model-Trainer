@echo off
setlocal
cd /d "%~dp0"
title Mustatil Dependencies Installer

echo ============================================================
echo Mustatil GUI - Install Python dependencies
echo ============================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    set PY=python
)

%PY% --version
if errorlevel 1 (
    echo.
    echo ERROR: Python was not found.
    echo Install Python 3.10 or 3.11 from python.org and enable Add Python to PATH.
    pause
    exit /b 1
)

echo.
echo Upgrading pip/setuptools/wheel...
%PY% -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto fail

echo.
echo Installing core runtime dependencies...
%PY% -m pip install pillow numpy pyyaml tqdm pandas matplotlib opencv-python
if errorlevel 1 goto fail

echo.
echo Installing PyTorch CPU build...
%PY% -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto fail

echo.
echo Installing Ultralytics and ONNX tools...
%PY% -m pip install ultralytics onnx onnxruntime onnxruntime-directml
if errorlevel 1 goto fail

echo.
echo Installing optional geospatial readers. Fiona/GeoPandas are intentionally NOT installed.
%PY% -m pip install rasterio shapely pyproj

echo.
echo Installing EXE build tool...
%PY% -m pip install pyinstaller
if errorlevel 1 goto fail

echo.
echo Done.
pause
exit /b 0

:fail
echo.
echo ERROR: Dependency installation failed.
echo Use Python 3.10 or 3.11. Python 3.14 is not recommended for Torch/Ultralytics/SAM.
pause
exit /b 1
