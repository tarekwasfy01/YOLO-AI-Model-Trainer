@echo off
setlocal
cd /d "%~dp0"
title Mustatil All GUIs

echo Starting Mustatil All GUIs...
where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    set PY=python
)

%PY% mustatil_all_guis.py
if errorlevel 1 (
    echo.
    echo The GUI exited with an error. Run INSTALL_DEPENDENCIES.bat first.
    pause
)
