Mustatil EXE build package - Rasterio + SAM2 BASE fix

Fixes in this package:
1) Rasterio hidden imports are explicitly included in the PyInstaller build.
   This fixes EXE preview errors such as missing rasterio.serde.
2) The SAM2 path bug is fixed: BASE is now defined correctly for normal Python
   and for PyInstaller EXE mode. Project data/weights are stored next to the EXE,
   not in the temporary PyInstaller folder.

Recommended build:
1. Run INSTALL_DEPENDENCIES.bat
2. Run BUILD_EXE_ONEDIR_FAST.bat
3. Start dist\Mustatil_All_GUIs\Mustatil_All_GUIs.exe

Important:
- Keep the whole dist\Mustatil_All_GUIs folder together.
- Put SAM2 .pt files into dist\Mustatil_All_GUIs\weights or select them with Browse.
- If a SAM2 .pt download was interrupted, delete the .broken file and use a complete model file.
