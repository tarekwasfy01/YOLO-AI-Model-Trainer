@echo off
setlocal
cd /d "%~dp0"
title Mustatil All GUIs DEBUG

where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3.11
) else (
    set PY=python
)

echo Python:
%PY% --version
echo.
echo Starting GUI with console output...
%PY% mustatil_all_guis.py
echo.
echo Program closed.
pause
