@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Mustatil All GUIs - Dependencies installieren

echo ================================================
echo Mustatil All GUIs - Dependency Installer
echo ================================================
echo.

set "PYEXE="
where py >nul 2>nul
if not errorlevel 1 (
    py -3.11 -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYEXE=py -3.11"
    if not defined PYEXE (
        py -3.10 -c "import sys" >nul 2>nul
        if not errorlevel 1 set "PYEXE=py -3.10"
    )
)
if not defined PYEXE (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
    echo FEHLER: Python wurde nicht gefunden.
    echo Bitte Python 3.10 oder 3.11 installieren.
    pause
    exit /b 1
)

echo Verwende Python: %PYEXE%
%PYEXE% -c "import sys; print(sys.version)"
echo.

echo [1/5] pip aktualisieren...
%PYEXE% -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto fail

echo.
echo [2/5] Basis-Pakete installieren...
%PYEXE% -m pip install pillow numpy pyyaml opencv-python tqdm pandas matplotlib scikit-learn
if errorlevel 1 goto fail

echo.
echo [3/5] PyTorch CPU installieren...
%PYEXE% -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto fail

echo.
echo [4/5] YOLO / ONNX installieren...
%PYEXE% -m pip install ultralytics onnx onnxruntime onnxruntime-directml
if errorlevel 1 goto fail

echo.
echo [5/5] Optionale GeoTIFF-Pakete installieren, nur fertige Wheels, kein GDAL-Build...
%PYEXE% -m pip install --only-binary=:all: rasterio shapely
if errorlevel 1 (
    echo.
    echo HINWEIS: rasterio/shapely konnten nicht installiert werden.
    echo Das ist nicht kritisch fuer JPG/PNG und normale Funktionen.
    echo Fuer grosse GeoTIFFs besser Python 3.10/3.11 verwenden.
)

echo.
echo Fertig. Starte danach START_MUSTATIL_ALL_GUIS.bat
echo.
pause
exit /b 0

:fail
echo.
echo FEHLER: Installation abgebrochen.
echo Bitte die komplette Fehlermeldung kopieren.
echo Tipp: Python 3.10 oder 3.11 ist fuer Torch/Ultralytics stabiler als Python 3.14.
pause
exit /b 1
