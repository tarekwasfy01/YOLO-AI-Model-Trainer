Mustatil All GUIs - funktionierende BAT-Dateien

Dateien:
1. INSTALL_DEPENDENCIES.bat
   Installiert die noetigen Pakete. Fiona/GeoPandas werden absichtlich NICHT installiert,
   damit kein GDAL-Buildfehler entsteht.

2. START_MUSTATIL_ALL_GUIS.bat
   Startet die GUI per Doppelklick und bleibt bei Fehlern offen.

3. START_DEBUG.bat
   Startet mit extra Diagnoseausgabe.

Hinweis:
Python 3.10 oder 3.11 ist empfohlen. Python 3.14 kann bei Torch/Ultralytics/SAM2 Probleme machen.
