@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Mustatil All GUIs - Debug Start

echo ================================================
echo Debug-Start mit kompletter Ausgabe
echo ================================================
echo.

set "PYEXE="
where py >nul 2>nul
if not errorlevel 1 (
    py -3.11 -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYEXE=py -3.11"
    if not defined PYEXE (
        py -3.10 -c "import sys" >nul 2>nul
        if not errorlevel 1 set "PYEXE=py -3.10"
    )
)
if not defined PYEXE (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
    echo FEHLER: Python wurde nicht gefunden.
    pause
    exit /b 1
)

echo Python-Befehl: %PYEXE%
%PYEXE% -c "import sys,platform; print(sys.executable); print(sys.version); print(platform.platform())"
echo.
echo Wichtige Imports:
%PYEXE% -c "mods=['PIL','numpy','cv2','yaml','torch','ultralytics','onnxruntime']; import importlib; [print(m, 'OK' if importlib.util.find_spec(m) else 'FEHLT') for m in mods]"
echo.
%PYEXE% -X faulthandler -u "mustatil_all_guis.py"
set "ERR=%ERRORLEVEL%"
echo.
echo Debug beendet mit Fehlercode %ERR%.
pause
exit /b %ERR%
