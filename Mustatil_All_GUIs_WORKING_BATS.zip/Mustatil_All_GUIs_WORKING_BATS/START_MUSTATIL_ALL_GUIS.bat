@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Mustatil All GUIs - Start

echo ================================================
echo Mustatil All GUIs - Start
echo Ordner: %CD%
echo ================================================
echo.

set "PYEXE="

where py >nul 2>nul
if not errorlevel 1 (
    py -3.11 -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYEXE=py -3.11"
    if not defined PYEXE (
        py -3.10 -c "import sys" >nul 2>nul
        if not errorlevel 1 set "PYEXE=py -3.10"
    )
)

if not defined PYEXE (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYEXE=python"
)

if not defined PYEXE (
    echo FEHLER: Python wurde nicht gefunden.
    echo Bitte Python 3.10 oder 3.11 installieren und dann INSTALL_DEPENDENCIES.bat ausfuehren.
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo Verwende Python: %PYEXE%
%PYEXE% -c "import sys; print('Version:', sys.version); raise SystemExit(0 if sys.version_info < (3,12) else 12)"
if errorlevel 12 (
    echo.
    echo WARNUNG: Du nutzt wahrscheinlich Python 3.12/3.13/3.14.
    echo Torch/Ultralytics/SAM2 laufen unter Python 3.10 oder 3.11 stabiler.
    echo Die GUI startet trotzdem, aber bei Problemen Python 3.11 installieren.
    echo.
)

if not exist "mustatil_all_guis.py" (
    echo FEHLER: mustatil_all_guis.py liegt nicht in diesem Ordner.
    pause
    exit /b 1
)

%PYEXE% -X faulthandler "mustatil_all_guis.py"
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
    echo Die GUI wurde mit Fehlercode %ERR% beendet.
    echo Bitte START_DEBUG.bat ausfuehren und die Fehlermeldung kopieren.
) else (
    echo GUI beendet.
)
pause
exit /b %ERR%
